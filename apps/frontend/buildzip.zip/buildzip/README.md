# Public Folder

This folder contains static assets that are served directly by the web server.

## Put here:
- Images, logos, favicons, or other static assets
- Robots.txt, etc.

> ✅ Anything in this folder is **not processed** by Webpack/Vite. Files are served as-is.